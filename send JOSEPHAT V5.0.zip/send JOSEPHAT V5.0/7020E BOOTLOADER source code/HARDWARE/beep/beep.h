/*
 * beep.h
 *
 *  Created on: 2017年5月16日
 *      Author: xianlee
 */

#ifndef BEEP_BEEP_H_
#define BEEP_BEEP_H_

void beep_init(void);

void beep_ms(unsigned int nms);

void beep_start(void);

void beep_stop(void);

#endif /* BEEP_BEEP_H_ */
