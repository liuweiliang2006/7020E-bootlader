#ifndef __BSP_BEEP_H
#define	__BSP_BEEP_H

#include "stm32f0xx.h"
void BEEP_Init(void);
#endif
