
#ifndef __KEY_H
#define __KEY_H

#include "stm32f0xx.h"

void KEY_Init(void);
void KEY_EXTI_Init(void);

#endif
